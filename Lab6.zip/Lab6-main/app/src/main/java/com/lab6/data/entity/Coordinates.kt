package com.lab6.data.entity

data class Coordinates(val lat: Double, val lon: Double)
