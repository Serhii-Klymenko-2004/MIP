package com.lab6.data.entity

data class WeatherForecast(
    val dt: Long,
    val main: WeatherMain,
)