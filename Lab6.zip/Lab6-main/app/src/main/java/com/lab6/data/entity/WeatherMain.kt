package com.lab6.data.entity

data class WeatherMain(
    val temp: Double,
    val feels_like: Double,
    val pressure: Int,
    val humidity: Int,

)