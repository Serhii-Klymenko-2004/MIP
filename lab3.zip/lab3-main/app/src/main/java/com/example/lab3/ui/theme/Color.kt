package com.example.lab3.ui.theme

import androidx.compose.ui.graphics.Color

val Green80 = Color(0xFF4CAF50)
val LightGreen80 = Color(0xFF8BC34A)
val Amber80 = Color(0xFFFFC107)