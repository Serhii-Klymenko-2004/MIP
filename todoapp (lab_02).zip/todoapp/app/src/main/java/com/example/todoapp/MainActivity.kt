package com.example.todoapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.tooling.preview.Preview
import com.example.todoapp.ui.theme.ToDoAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ToDoAppTheme {
                ToDoApp()
            }
        }
    }
}

data class TaskItem( // Клас для завдань
    val text: String,
    var isChecked: Boolean = false
)

@Composable
fun ToDoApp() {
    var taskText by remember { mutableStateOf("") } // Поле для вводу тексту
    val taskList = remember { mutableStateListOf<TaskItem>() } // Список завдань

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "ToDo Список",
            style = MaterialTheme.typography.headlineMedium,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Поле для вводу завдання
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = taskText,
                onValueChange = { taskText = it },
                label = { Text("Введіть завдання") },
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = {
                    if (taskText.isNotEmpty()) {
                        taskList.add(TaskItem(text = taskText)) // Додаємо нове завдання
                        taskText = "" // Очищаємо поле вводу
                    }
                }
            ) {
                Text("Додати")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Відображення списку завдань з чекбоксами
        LazyColumn {
            items(taskList) { task ->
                TaskRow(taskItem = task)
            }
        }
    }
}

@Composable
fun TaskRow(taskItem: TaskItem) {
    var isChecked by remember { mutableStateOf(taskItem.isChecked) } // Стан для чекбоксу

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = isChecked,
            onCheckedChange = { isChecked = it; taskItem.isChecked = it }
        )
        Text(
            text = taskItem.text,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(start = 8.dp)
        )
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    ToDoAppTheme {
        ToDoApp()
    }
}
