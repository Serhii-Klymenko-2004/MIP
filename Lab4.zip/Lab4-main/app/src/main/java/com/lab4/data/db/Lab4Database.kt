package com.lab4.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.lab4.data.dao.SubjectDao
import com.lab4.data.dao.SubjectLabsDao
import com.lab4.data.entity.SubjectEntity
import com.lab4.data.entity.SubjectLabEntity
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Lab4Database - the main database class
 * - extends on RoomDatabase()
 * - marked with @Database annotation for generating communication interfaces
 * - in annotation are added all your entities (tables)
 * - includes abstract properties of all DAO interfaces for each entity (table)
 */
@Database(entities = [SubjectEntity::class, SubjectLabEntity::class], version = 1)
abstract class Lab4Database : RoomDatabase() {
    //DAO properties for each entity (table)
    // must be abstract (because Room will generate instances by itself)
    abstract val subjectsDao: SubjectDao
    abstract val subjectLabsDao: SubjectLabsDao
}

/**
 * DatabaseStorage - custom class where you initialize and store Lab4Database single instance
 *
 */
object DatabaseStorage {
    // ! Important - all operations with DB must be done from non-UI thread!
    // coroutineScope: CoroutineScope - is the scope which allows to run asynchronous operations
    // > we will learn it soon! For now just put it here
    private val coroutineScope = CoroutineScope(
        SupervisorJob() + Dispatchers.IO + CoroutineExceptionHandler { _, throwable ->
            throwable.printStackTrace()
        },
    )

    // single instance of Lab4Database
    private var _database: Lab4Database? = null

    /**
        Function of initializing and getting Lab4Database instance
        - is invoked from place where DB should be used (from Compose screens)
        [context] - context from Compose screen to init DB
    */
    fun getDatabase(context: Context): Lab4Database {
        // if _database already contains Lab4Database instance, return this instance
        if (_database != null) return _database as Lab4Database
        // if not, create instance, preload some data and return this instance
        else {
            // creating Lab4Database instance by builder
            _database = Room.databaseBuilder(
                context,
                Lab4Database::class.java, "lab4Database"
            ).build()

            // preloading some data to DB
            preloadData()

            return _database as Lab4Database
        }
    }

    /**
        Function for preloading some initial data to DB
     */
    private fun preloadData() {
        // List of subjects
        val listOfSubject = listOf(
            SubjectEntity(id = 1, title = "Мобільні Інфокомунікаційні платформи"),
            SubjectEntity(id = 2, title = "Технології представлення даних та СУБД в інфокомунікаціях"),
            SubjectEntity(id = 3, title = "Об'єктно-орієнтоване програмування С++"),
            SubjectEntity(id = 4, title = "Електроживлення пристроїв та систем"),
            SubjectEntity(id = 5, title = "Основи проєтування програмного забезпечення інфоккомунікацій"),
        )
        // List of labs
        val listOfSubjectLabs = listOf(
            SubjectLabEntity(
                id = 1,
                subjectId = 1,
                title = "Знайомство з Android ",
                description = "Встановлення середовища розробки",
                comment = "Дедлайн 09.17" ,
            ),
            SubjectLabEntity(
                id = 2,
                subjectId = 1,
                title = "Вивчення UI операцій",
                description = "Написати простий ToDo додаток",
                comment = "Виконано" ,
                isCompleted = true
            ),

            SubjectLabEntity(
                id = 3,
                subjectId = 2,
                title = "Робота з базами даних: MySQL",
                description = "Встановлення MySQL на локальну машину, створення таблиць та виконання основних SQL-запитів.",
                comment = "Перевірити правильність запитів",
                inProgress = true
            ),
            SubjectLabEntity(
                id = 4,
                subjectId = 2,
                title = "Розробка REST API для роботи з базою даних",
                description = "Створення простого REST API для CRUD операцій за допомогою Node.js та Express.",
                comment = "Захист у середу",
                isCompleted = false
            ),
            SubjectLabEntity(
                id = 5,
                subjectId = 3,
                title = "Введення в STL (Standard Template Library)",
                description = "Ознайомлення з основними контейнерами STL (vector, list, map) і реалізація задачі сортування даних.",
                comment = "Написати приклади коду",
                isCompleted = false
            ),
            SubjectLabEntity(
                id = 6,
                subjectId = 3,
                title = "Наслідування та поліморфізм у C++",
                description = "Реалізація ієрархії класів для моделювання об’єктів у програмі, демонстрація поліморфізму.",
                comment = "Захист наступного тижня",
                isCompleted = false
            ),
            SubjectLabEntity(
                id = 7,
                subjectId = 4,
                title = "Проєктування блоку живлення",
                description = "Розробити схему блоку живлення для заданих параметрів. Пояснити принцип роботи та розрахунки.",
                comment = "Зробити креслення у Proteus",
                isCompleted = true
            ),
            SubjectLabEntity(
                id = 8,
                subjectId = 4,
                title = "Налаштування UPS для мережевого обладнання",
                description = "Вивчити принципи роботи джерел безперебійного живлення (UPS). Налаштувати UPS для комутатора.",
                comment = "Підготувати технічну документацію",
                inProgress = true
            ),
            SubjectLabEntity(
                id = 9,
                subjectId = 5,
                title = "Розробка UML-діаграм для інформаційної системи",
                description = "Створення діаграм класів, послідовності та прецедентів для моделювання інформаційної системи.",
                comment = "Перевірити відповідність специфікації",
                inProgress = true
            ),
            SubjectLabEntity(
                id = 10,
                subjectId = 5,
                title = "Прототипування інтерфейсу користувача",
                description = "Розробити прототип інтерфейсу користувача для заданої системи з використанням Figma або іншого інструмента.",
                comment = "Здати до кінця тижня",
                isCompleted = false
            )
        )

        // Request to add all Subjects from the list to DB
        listOfSubject.forEach { subject ->
            // coroutineScope.launch{...} - start small thread where you can make query to DB
            coroutineScope.launch {
                // INSERT query to add Subject (subjectsDao is used)
                _database?.subjectsDao?.addSubject(subject)
            }
        }
        // Request to add all Labs from the list to DB
        listOfSubjectLabs.forEach { lab ->
            coroutineScope.launch {
                // INSERT query to add Lab (subjectLabsDao is used)
                _database?.subjectLabsDao?.addSubjectLab(lab)
            }
        }
    }
}